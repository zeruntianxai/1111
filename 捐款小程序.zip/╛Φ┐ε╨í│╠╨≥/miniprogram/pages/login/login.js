// pages/login/login.js
let app = getApp();
// 获取云数据库引用
wx.cloud.init({
  env: 'wuzijuanzhu-xruwn'//环境ID
})
const db = wx.cloud.database({
  env: 'wuzijuanzhu-xruwn'
});
const admin = db.collection('user');
let name = null;
let password = null;

Page({
  data: {
    userInfo: {},
    userN: '',
    passW: ''
  },
  userNameInput: function (e) {
    this.setData({
      userN: e.detail.value
    })
  },
  passWordInput: function (e) {
    this.setData({
      passW: e.detail.value
    })
  },
  loginBtnClick: function (a) {
    var that = this
    if (this.data.userN.length == 0 || this.data.passW.length == 0) {
      wx.showModal({
        title: '温馨提示：',
        content: '用户名或密码不能为空！',
        showCancel: false
      })
    } else {
      db.collection('user').where({name: that.data.userN }).get({
        success: function (res) {

          if (that.data.passW == res.data[0].password) {
            wx.navigateTo({
              url: '/pages/register/index'//[主页面]
            })
          }
          else {
            wx.showModal({
              title: '密码错误',
              content: '密码错误'//session中用户名和密码不为空触发
            });
          }
        }
      })
    }
  },
  register() {
    wx.navigateTo({
      url: '/pages/register/index'
    })
  },
  /**
     * 生命周期函数--监听页面加载
     */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   * 页面初次渲染完成时触发。一个页面只会调用一次，代表页面已经准备妥当，可以和视图层进行交互
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   * 页面显示/切入前台时触发
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})


  




